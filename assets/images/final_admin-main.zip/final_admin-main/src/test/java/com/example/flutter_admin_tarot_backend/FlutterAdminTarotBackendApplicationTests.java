package com.example.flutter_admin_tarot_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlutterAdminTarotBackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
